# 单细胞RNA 速率

## 研究背景

单细胞RNA测序可以精确的、高通量的揭示RNA丰度。单细胞RNA测序可以精确的、高通量的揭示RNA丰度。对于分析胚胎形成或者组织重建的这种需要观测连续时间的“事件”就比较困难了。“RNA velocity”（RNA速率）被提出了，可以直接测定在单细胞测序结果中的“未成熟”mRNA和“成熟”mRNA。

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-12-10-25-57-image.png)

在发育过程中，分化过程发生在时间轴上的几小时到数天不等。而未成熟的mRNA（unspliced）和成熟的mRNA（spliced）的相对丰度可以评估基因剪切和降解的速率。

模型提出：成熟的mRNA丰度由未成熟mRNA产生的spliced mRNA和降解的速度来决定（图1b）

用bulk-RNA-seq方法检测了小鼠肝脏的日周期的一个时间过程

许多与节律相关的基因也展示出了unspliced mRNA的上调的趋势（图1f,g）

## 实战

## 加载scvelo包，设置可视化环境

```
import scvelo as scv
scv.set_figure_params()
```

## 读取数据（loom, h5ad，csv）

```
adata = scv.read(filename, cache=True)
```

```
#分析基于软件自带的胰腺数据
adata = scv.datasets.pancreas()
adata
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-15-34-07-image.png)

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-12-15-41-14-image.png)

```
scv.pl.proportions(adata)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-12-50-01-filename.jpg)

## 预处理数据

```
#预处理包括通过检测（count数最少）和高变异性（分散）进行基因选择，按其总大小使每个细胞标准化。
scv.pp.filter_genes(adata, min_shared_counts=20)
scv.pp.normalize_per_cell(adata)
scv.pp.filter_genes_dispersion(adata, n_top_genes=2000)
scv.pp.log1p(adata)
```

```
scv.pp.filter_and_normalize(adata, min_shared_counts=20, n_top_genes=2000)
#计算一阶和二阶矩
scv.pp.moments(adata, n_pcs=30, n_neighbors=30)
```

## 一般模型

假设前提：转录组范围内的剪接率，并且基因表达遵循稳态

## RNA速率计算

```
scv.tl.velocity(adata)
scv.tl.velocity_graph(adata)
```

## 投射速率可视化

```
#流线型
scv.pl.velocity_embedding_stream(adata, basis='umap')
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-11-55-53-embedding_stream.jpg)

```
#细胞水平
scv.pl.velocity_embedding(adata, arrow_length=3, arrow_size=2, dpi=240)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-11-56-26-embedding.jpg)

```
#网格型
scv.pl.velocity_embedding_grid(adata, basis='umap')
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-12-00-05-embedding_grid.jpg)

## 解释速率

不要将生物结论限制在预测速率上，而是通过图像来检查个体基因动力学，以了解特定基因如何支持推断方向

[图解](https://user-images.githubusercontent.com/31883718/80227452-eb822480-864d-11ea-9399-56886c5e2785.gif)

基因活动是由转录调控的，特定基因的转录诱导导致（新转录的）前体未剪切 mRNA 增加，而相反，抑制或没有转录会导致未转录 mRNA 的减少，拼接的 mRNA 由未剪切的 mRNA 生成，并遵循相同的趋势，并具有时间滞后性。时间是一个隐藏/潜在的变量。因此，需要从实际测量中推断出动态：phase portrait中展示的剪切和未剪切的 mRNA。

phase portraits of some marker genes

```
scv.pl.velocity(adata, ['Cpe',  'Gnao1', 'Ins2', 'Adk'], ncols=1)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-12-05-08-gene.jpg)

对角黑线对应着估计的"稳定状态"的未剪切/剪切比率，即unspliced和spliced的 mRNA 丰度比值。spliced的 mRNA 丰度处于恒定的转录状态。特定基因的RNA速率被确定为残差(residual)，也就是观察值与稳定状态线的偏差程度，正速率表示基因被向上调节，这发生在细胞显示该基因的未剪切mRNA的丰度高于预期的稳定状态。相反，负速率表示基因表达降低。

*Cpe*可以解释上调的**Ngn3**(黄色)到**Pre endocrine** (橙色)再到β-细胞(绿色)的分化方向，而*Adk*则解释了下调的**Ductal**(深绿色)到**Ngn3**(黄色)再到**remaining endocrine**细胞的方向。

```
scv.pl.scatter(adata, 'Cpe', color=['clusters', 'velocity'],
               add_outline='Ngn3 high EP, Pre-endocrine, Beta')
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-13-09-08-gene.scatter.jpg)

## 鉴定关键基因

我们需要一种系统的方法来鉴定基因，这有助于解释由此产生的向量场和推断谱系。可以测试哪些基因具有群体特异性速率表达（可理解为差异速率分析），可以检验哪些基因相比于其他群具有群特异性速率表达（比如在高速率细胞群中高表达或低表达）

```
scv.tl.rank_velocity_genes(adata, groupby='clusters', min_corr=.3)
df = scv.DataFrame(adata.uns['rank_velocity_genes']['names'])
df.head()
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-13-15-47-image.png)

```
kwargs = dict(frameon=False, size=10, linewidth=1.5,
              add_outline='Ngn3 high EP, Pre-endocrine, Beta')

scv.pl.scatter(adata, df['Ngn3 high EP'][:5], ylabel='Ngn3 high EP', **kwargs)
scv.pl.scatter(adata, df['Pre-endocrine'][:5], ylabel='Pre-endocrine', **kwargs)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-13-30-28-image.png)

*Ptprs, Pclo, Pam, Abcc8, Gnas*基因支持从**Ngn3 high EP**（黄色）到**Pre-endocrine**（橙色）到**Beta**（绿色）的方向性。

## 周期前体细胞速率

RNA速率检测到的细胞周期，通过细胞周期评分（相标记基因平均表达水平的标准化分数）在生物学上得到了证实。

```
scv.tl.score_genes_cell_cycle(adata)
scv.pl.scatter(adata, color_gradients=['S_score', 'G2M_score'], smooth=True, perc=[5, 95])
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-13-33-24-cycle.jpg)

对于循环导管细胞，我们可以筛选S和G2M期的marker。前一个模块还计算了一个spearmans 相关系数，用它来对phase marker基因进行排序，然后显示它们的phase portraits

```
s_genes, g2m_genes = scv.utils.get_phase_marker_genes(adata)
s_genes = scv.get_df(adata[:, s_genes], 'spearmans_score', sort_values=True).index
g2m_genes = scv.get_df(adata[:, g2m_genes], 'spearmans_score', sort_values=True).index

kwargs = dict(frameon=False, ylabel='cell cycle genes')
scv.pl.scatter(adata, list(s_genes[:2]) + list(g2m_genes[:3]), **kwargs)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-13-38-52-image.png)

尤其是*Hells* 和*Top2a*非常适合解释周期前体细胞的矢量场，*Top2a* 在 G2M期实际达到峰值前不久被分配了高速，负的速率和随后的下调完美匹配。

```
scv.pl.velocity(adata, ['Hells', 'Top2a'], ncols=2, add_outline=True)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-13-42-19-g2m.gene.jpg)

## 速率和连贯性

分化的速度/速率由速率矢量的长度给出；

矢量场的一致性（即速率矢量如何与其邻近速率相关）提供了置信度的衡量标准； 

```
scv.tl.velocity_confidence(adata)
keys = 'velocity_length', 'velocity_confidence'
scv.pl.scatter(adata, c=keys, cmap='coolwarm', perc=[5, 95])
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-13-50-57-lenegth_confidence.jpg)

```
df = adata.obs.groupby('clusters')[keys].mean().T
df.style.background_gradient(cmap='coolwarm', axis=1)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-13-53-43-image.png)

## 速率图和拟时序

```
scv.pl.velocity_graph(adata, threshold=.1)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-13-59-35-pseudotime.jpg)

```
x, y = scv.utils.get_cell_transitions(adata, basis='umap', starting_cell=70)
ax = scv.pl.velocity_graph(adata, c='lightgrey', edge_width=.05, show=False)
ax = scv.pl.scatter(adata, x=x, y=y, s=120, c='ascending', cmap='gnuplot', ax=ax)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-14-04-52-pre-endocrine.jpg)

```
scv.tl.velocity_pseudotime(adata)
scv.pl.scatter(adata, color='velocity_pseudotime', cmap='gnuplot')
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-14-11-00-velocity_pseudotime.jpg)

## Partition-based graph abstraction (PAGA)

```
adata.uns['neighbors']['distances'] = adata.obsp['dimport pandas as pdistances']
adata.uns['neighbors']['connectivities'] = adata.obsp['connectivities']

scv.tl.paga(adata, groups='clusters')
#import pandas as pd
#pd.options.display.max_rows = 999
df = scv.get_df(adata, 'paga/transitions_confidence',  pd.options.display.precision==2).T
#美化图标
df.style.background_gradient(cmap='Blues').format('{:.2g}')
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-19-12-58-image.png)

```
scv.pl.paga(adata, basis='umap', size=50, alpha=.1,
            min_edge_width=2, node_size_scale=1.5)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-19-21-12-paga.jpg)

# 

# # 动态模型（Dynamical Modeling）

```
import scvelo as scv
scv.logging.print_version()
```

```
scv.settings.verbosity = 3  # show errors(0), warnings(1), info(2), hints(3)
scv.settings.presenter_view = True  # set max width size for presenter view
scv.settings.set_figure_params('scvelo')  # for beautified visualization
```

```
scv.tl.recover_dynamics(adata)
scv.tl.velocity(adata, mode='dynamical')
scv.tl.velocity_graph(adata)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-21-50-27-dynamics_embedded.png)

```
df = adata.var
df = df[(df['fit_likelihood'] > .1) & df['velocity_genes'] == True]

kwargs = dict(xscale='log', fontsize=16)
with scv.GridSpec(ncols=3) as pl:
    pl.hist(df['fit_alpha'], xlabel='transcription rate', **kwargs)
    pl.hist(df['fit_beta'] * df['fit_scaling'], xlabel='splicing rate', xticks=[.1, .4, 1], **kwargs)
    pl.hist(df['fit_gamma'], xlabel='degradation rate', xticks=[.1, .4, 1], **kwargs)

scv.get_df(adata, 'fit*', dropna=True).head()
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-21-54-59-GridSpec.jpg)

```
scv.tl.latent_time(adata)
scv.pl.scatter(adata, color='latent_time', color_map='gnuplot', size=80)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-22-03-33-latent.scatter.jpg)

```
top_genes = adata.var['fit_likelihood'].sort_values(ascending=False).index[:300]
scv.pl.heatmap(adata, var_names=top_genes, sortby='latent_time', col_color='clusters', n_convolve=100)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-22-12-28-latent.heatmap.png)

```
top_genes = adata.var['fit_likelihood'].sort_values(ascending=False).index
scv.pl.scatter(adata, basis=top_genes[:15], ncols=5, frameon=False)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-22-18-26-topgene.jpg)

```
var_names = ['Actn4', 'Ppp3ca', 'Cpe', 'Nnat']
scv.pl.scatter(adata, var_names, frameon=False)
scv.pl.scatter(adata, x='latent_time', y=var_names, frameon=False)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-22-23-44-topgene3.jpg)

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-22-24-45-topgene2.jpg)

```
scv.tl.rank_dynamical_genes(adata, groupby='clusters')
df = scv.get_df(adata, 'rank_dynamical_genes/names')
df.head(5)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-22-26-12-image.png)

```
for cluster in ['Ductal', 'Ngn3 high EP', 'Pre-endocrine', 'Beta']:
    scv.pl.scatter(adata, df[cluster][:5], ylabel=cluster, frameon=False)
```

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-22-46-17-Beta.jpg)

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-22-46-51-Ductal.jpg)

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-22-47-50-Ngn3_high_EP.jpg)

![](C:\Users\wangm\AppData\Roaming\marktext\images\2022-05-10-22-48-05-Pre-endocrine.jpg)

# Differential Kinetics
